<?php
// Konfigurasi API
$YOUTUBE_API_KEY = 'AIzaSyBkkfjK5MdYtYnLeBQiZn7rgbKMyN3SC5c';
$YOUTUBE_CHANNEL_ID = 'UCfCmMfkDhkkfPkGhk6Pr-Hg';
$INSTAGRAM_ACCESS_TOKEN = 'IGAA8aPVQwxodBZAE1hTC1iaUtnUlpBYlREcEtkZAm5SLTVTdE1YSFM2ekF3dFlBT1J2WGJxbU5FWU1OMGlET0hHNWNzS3lhX0xpVW93b3JHRzdqS0NnTE9PejA3VGdqUGhXUW93dlk5WXdVRlBEcFdtSDBBVVdtVEF3N19MTDZAycwZDZD';

function get_CURL($url)
{
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($curl);
    curl_close($curl);

    return json_decode($result, true); // HARUS di-return
}

// YouTube Data
$result = get_CURL("https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&id={$YOUTUBE_CHANNEL_ID}&key={$YOUTUBE_API_KEY}");

$youtubeProfilePic = $result['items'][0]['snippet']['thumbnails']['medium']['url'];
$channelName = $result['items'][0]['snippet']['title'];
$subscriber = $result['items'][0]['statistics']['subscriberCount'];

// Latest YouTube Video
$urlLatestVideo = "https://www.googleapis.com/youtube/v3/search?key={$YOUTUBE_API_KEY}&channelId={$YOUTUBE_CHANNEL_ID}&maxResult=1&order=date&part=snippet";
$result = get_CURL($urlLatestVideo);
$LatestVideoId = $result['items']['0']['id']['videoId'];

class InstagramAPI {
    private $access_token;
    private $api_base_url = 'https://graph.instagram.com/';
    
    public function __construct($access_token) {
        $this->access_token = $access_token;
    }
    
    /**
     * Mengambil informasi profil pengguna Instagram
     * Termasuk followers_count dan profile picture jika tersedia
     */
    public function getUserProfile() {
        $fields = 'id,username,media_count,account_type,followers_count';
        $url = $this->api_base_url . "me?fields={$fields}&access_token={$this->access_token}";
        
        return $this->makeRequest($url);
    }
    
    /**
     * Mengambil foto profil Instagram (dari post terbaru sebagai fallback)
     */
    public function getProfilePicture() {
        try {
            $media = $this->getUserMedia(1);
            if (isset($media['data'][0]['media_url'])) {
                return $media['data'][0]['media_url'];
            }
        } catch (Exception $e) {
            return 'data:image/svg+xml;base64,' . base64_encode('
                <svg width="80" height="80" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="40" cy="40" r="40" fill="#e1306c"/>
                    <circle cx="40" cy="35" r="12" fill="white"/>
                    <circle cx="40" cy="55" r="18" fill="white"/>
                </svg>
            ');
        }
        return null;
    }
    
    /**
     * Mengambil data media terbaru
     */
    public function getUserMedia($limit = 6) {
        $fields = 'id,caption,media_type,media_url,thumbnail_url,permalink,timestamp,like_count,comments_count';
        $url = $this->api_base_url . "me/media?fields={$fields}&limit={$limit}&access_token={$this->access_token}";
        
        return $this->makeRequest($url);
    }
    
    /**
     * IMPLEMENTASI cURL - Melakukan HTTP request ke Instagram API
     */
    private function makeRequest($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Portfolio Website/1.0');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'Cache-Control: no-cache'
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);
        
        if ($curl_error) {
            throw new Exception("cURL Error: " . $curl_error);
        }
        
        if ($http_code !== 200) {
            $error_msg = "Instagram API Error: HTTP {$http_code}";
            if ($response) {
                $error_data = json_decode($response, true);
                if (isset($error_data['error']['message'])) {
                    $error_msg .= " - " . $error_data['error']['message'];
                }
            }
            throw new Exception($error_msg);
        }
        
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("JSON Decode Error: " . json_last_error_msg());
        }
        
        if (isset($data['error'])) {
            throw new Exception("Instagram API Error: " . $data['error']['message']);
        }
        
        return $data;
    }
    
    /**
     * Menyimpan data ke cache dengan error handling yang lebih baik
     */
public function getCachedData($cache_file = 'instagram_cache.json', $cache_duration = 3600) {
    $cache_path = __DIR__ . '/' . $cache_file;
    
    // Check if cache exists and is valid
    if (file_exists($cache_path)) {
        $cache_content = file_get_contents($cache_path);
        if ($cache_content) {
            $cache_data = json_decode($cache_content, true);
            // Verify $cache_data is an array and has the required keys
            if (is_array($cache_data) && isset($cache_data['timestamp']) && isset($cache_data['data']) && (time() - $cache_data['timestamp']) < $cache_duration) {
                return $cache_data['data'];
            }
        }
    }
    
    try {
        $profile = $this->getUserProfile();
        $media = $this->getUserMedia(6);
        
        $data = [
            'profile' => $profile,
            'media' => $media,
            'last_updated' => date('Y-m-d H:i:s'),
            'timestamp' => time() // Add timestamp for cache validation
        ];
        
        if (!is_writable(dirname($cache_path))) {
            throw new Exception("Cache directory tidak writable");
        }
        
        // Write the new $data to the cache file
        file_put_contents($cache_path, json_encode($data, JSON_PRETTY_PRINT));
        
        return $data;
        
    } catch (Exception $e) {
        // Try to return cached data if available
        if (file_exists($cache_path)) {
            $cache_content = file_get_contents($cache_path);
            if ($cache_content) {
                $cache_data = json_decode($cache_content, true);
                if (is_array($cache_data) && isset($cache_data['data'])) {
                    $cache_data['data']['from_cache'] = true;
                    $cache_data['data']['cache_error'] = $e->getMessage();
                    return $cache_data['data'];
                }
            }
        }
        throw $e;
    }
}    
    /**
     * Method untuk debug cURL request
     */
    public function debugRequest($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        
        $verbose = fopen('php://temp', 'w+');
        curl_setopt($ch, CURLOPT_STDERR, $verbose);
        
        $response = curl_exec($ch);
        $info = curl_getinfo($ch);
        
        rewind($verbose);
        $verbose_log = stream_get_contents($verbose);
        fclose($verbose);
        curl_close($ch);
        
        return [
            'response' => $response,
            'info' => $info,
            'verbose' => $verbose_log
        ];
    }
}

// Fungsi untuk menampilkan data Instagram di website
function displayInstagramProfile() {
    global $INSTAGRAM_ACCESS_TOKEN;
    
    try {
        $instagram = new InstagramAPI($INSTAGRAM_ACCESS_TOKEN);
        $data = $instagram->getCachedData();
        
        $profile = $data['profile'];
        $media = $data['media'];
        
        echo '<div class="instagram-section">';
        echo '<div class="profile-header">';
        
        echo '<div class="profile-picture">';
        echo '<div class="avatar-circle">';
        echo '<svg width="80" height="80" viewBox="0 0 80 80">';
        echo '<circle cx="40" cy="40" r="40" fill="#00bcd4"/>';
        echo '<span class="initials">RF</span>';
        echo '</svg>';
        echo '</div>';
        echo '</div>';
        
        echo '<div class="profile-details">';
        echo '<h3 class="username">@' . htmlspecialchars($profile['username']) . '</h3>';
        
        if (isset($profile['followers_count'])) {
            echo '<p class="followers-text">Followers: ' . number_format($profile['followers_count']) . '</p>';
        } else {
            echo '<p class="followers-text">Followers: -</p>';
        }
        
        echo '</div>';
        echo '</div>';
        
        if (isset($media['data']) && !empty($media['data'])) {
            echo '<div class="instagram-gallery">';
            echo '<div class="gallery-grid">';
            
            foreach (array_slice($media['data'], 0, 6) as $post) {
                $image_url = $post['media_type'] === 'VIDEO' ? 
                    (isset($post['thumbnail_url']) ? $post['thumbnail_url'] : $post['media_url']) : 
                    $post['media_url'];
                
                echo '<div class="instagram-post">';
                echo '<a href="' . $post['permalink'] . '" target="_blank">';
                echo '<img src="' . $image_url . '" alt="Instagram Post" loading="lazy">';
                echo '</a>';
                echo '</div>';
            }
            
            echo '</div>';
            echo '</div>';
        }
        
        echo '</div>';
        
    } catch (Exception $e) {
        echo '<div class="instagram-error">';
        echo '<p>Tidak dapat memuat data Instagram saat ini.</p>';
        echo '</div>';
    }
}

// CSS Styling
function instagramCSS() {
    echo '<style>
    .instagram-section {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        background: #f8f9fa;
        border-radius: 12px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    
    .profile-header {
        display: flex;
        align-items: center;
        margin-bottom: 20px;
        padding-bottom: 15px;
    }
    
    .profile-picture {
        margin-right: 15px;
        flex-shrink: 0;
    }
    
    .avatar-circle {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        overflow: hidden;
        background: #00bcd4;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .profile-details {
        flex: 1;
    }
    
    .username {
        color: #333;
        margin: 0 0 8px 0;
        font-size: 18px;
        font-weight: 600;
        line-height: 1.2;
    }
    
    .followers-text {
        color: #666;
        font-size: 14px;
        margin: 0;
        font-weight: 400;
    }
    
    .gallery-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
    }
    
    .instagram-post {
        overflow: hidden;
        border-radius: 8px;
        aspect-ratio: 1;
        background: #ddd;
    }
    
    .instagram-post img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.2s ease;
    }
    
    .instagram-post:hover img {
        transform: scale(1.02);
    }
    
    .instagram-error {
        text-align: center;
        color: #666;
        padding: 20px;
        font-size: 14px;
    }
    
    @media (max-width: 768px) {
        .instagram-section {
            margin: 10px;
            padding: 15px;
        }
        
        .avatar-circle {
            width: 60px;
            height: 60px;
        }
        
        .avatar-circle svg {
            width: 60px;
            height: 60px;
        }
        
        .username {
            font-size: 16px;
        }
        
        .followers-text {
            font-size: 13px;
        }
        
        .gallery-grid {
            gap: 6px;
        }
    }
    </style>';
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <title>My Portfolio</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#home">Ramelsi Fadhila</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="#home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#about">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#portfolio">Portfolio</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="jumbotron" id="home">
      <div class="container">
        <div class="text-center">
          <img src="img/profile2.png" class="rounded-circle img-thumbnail">
          <h1 class="display-4">Ramelsi Fadhila</h1>
          <h3 class="lead">Lecturer | Programmer | Youtuber</h3>
        </div>
      </div>
    </div>

    <section class="about" id="about">
      <div class="container">
        <div class="row mb-4">
          <div class="col text-center">
            <h2>About</h2>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-md-5">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, molestiae sunt doloribus error ullam expedita cumque blanditiis quas vero, qui, consectetur modi possimus. Consequuntur optio ad quae possimus, debitis earum.</p>
          </div>
          <div class="col-md-5">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, molestiae sunt doloribus error ullam expedita cumque blanditiis quas vero, qui, consectetur modi possimus. Consequuntur optio ad quae possimus, debitis earum.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="social bg-light" id="social">
      <div class="container">
        <div class="row pt-4 mb-4">
          <div class="col text-center">
            <h2>Social Media</h2>
          </div>
        </div>
        
        <div class="row justify-content-center">
          <div class="col-md-5">
            <div class="row">
              <div class="col-md-4">
                <img src="<?= $youtubeProfilePic; ?>" width="100" class="rounded-circle img-thumbnail">
              </div>
              <div class="col-md-8">
                <h5><?= $channelName; ?></h5>
                <p><?= $subscriber; ?> Subscriber</p>
                <div class="g-ytsubscribe" data-channelid="<?= $YOUTUBE_CHANNEL_ID; ?>" data-layout="default" data-count="default"></div>
              </div>
            </div>

            <div class="row mt-3 pb-3">
              <div class="col">
                <div class="ratio ratio-16x9">
                  <iframe 
                    src="https://www.youtube.com/embed/<?= $LatestVideoId; ?>?rel=0" 
                    title="YouTube video" allowfullscreen></iframe>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-5">
            <?php displayInstagramProfile(); ?>
            <?php instagramCSS(); ?>
          </div>
        </div>
      </div>
    </section>

    <section class="portfolio" id="portfolio">
      <div class="container">
        <div class="row pt-4 mb-4">
          <div class="col text-center">
            <h2>Portfolio</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md mb-4">
            <div class="card">
              <img class="card-img-top" src="img/thumbs/1.png" alt="Card image cap">
              <div class="card-body">
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
            </div>
          </div>

          <div class="col-md mb-4">
            <div class="card">
              <img class="card-img-top" src="img/thumbs/2.png" alt="Card image cap">
              <div class="card-body">
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
            </div>
          </div>

          <div class="col-md mb-4">
            <div class="card">
              <img class="card-img-top" src="img/thumbs/3.png" alt="Card image cap">
              <div class="card-body">
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
            </div>
          </div>   
        </div>

        <div class="row">
          <div class="col-md mb-4">
            <div class="card">
              <img class="card-img-top" src="img/thumbs/4.png" alt="Card image cap">
              <div class="card-body">
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
            </div>
          </div> 
          <div class="col-md mb-4">
            <div class="card">
              <img class="card-img-top" src="img/thumbs/5.png" alt="Card image cap">
              <div class="card-body">
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
            </div>
          </div>

          <div class="col-md mb-4">
            <div class="card">
              <img class="card-img-top" src="img/thumbs/6.png" alt="Card image cap">
              <div class="card-body">
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="contact bg-light" id="contact">
      <div class="container">
        <div class="row pt-4 mb-4">
          <div class="col text-center">
            <h2>Contact</h2>
          </div>
        </div>

        <div class="row justify-content-center">
          <div class="col-lg-4">
            <div class="card bg-primary text-white mb-4 text-center">
              <div class="card-body">
                <h5 class="card-title">Contact Me</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
            </div>
            
            <ul class="list-group mb-4">
              <li class="list-group-item"><h3>Location</h3></li>
              <li class="list-group-item">My Office</li>
              <li class="list-group-item">Jl. Setiabudhi No. 193, Bandung</li>
              <li class="list-group-item">West Java, Indonesia</li>
            </ul>
          </div>

          <div class="col-lg-6">
            <form>
              <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" class="form-control" id="nama">
              </div>
              <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control" id="email">
              </div>
              <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" class="form-control" id="phone">
              </div>
              <div class="form-group">
                <label for="message">Message</label>
                <textarea class="form-control" id="message" rows="3"></textarea>
              </div>
              <div class="form-group">
                <button type="button" class="btn btn-primary">Send Message</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <footer class="bg-dark text-white mt-5">
      <div class="container">
        <div class="row">
          <div class="col text-center">
            <p>Copyright © 2018.</p>
          </div>
        </div>
      </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <script src="https://apis.google.com/js/platform.js"></script>  
  </body>
</html>